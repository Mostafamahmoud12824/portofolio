import React from "react";

const Team = () => {
  return <h1>Our Team</h1>;
};

export default Team;
