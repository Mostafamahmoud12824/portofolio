import React from "react";

const Company = () => {
  return <h1>Our Company</h1>;
};

export default Company;
