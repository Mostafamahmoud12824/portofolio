import React, { Component } from "react";

class Contact extends Component {
  state = {};
  render() {
    return <h1>Contact Us</h1>;
  }
}

export default Contact;
