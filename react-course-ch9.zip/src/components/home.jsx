import React, { Component } from "react";

class Home extends Component {
  state = {};
  render() {
    return <h1>Home</h1>;
  }
}

export default Home;
